#!/data/data/com.termux/files/usr/bin/bash
# Onyx Cloud — start.sh v4 (paksa single instance)

cd "$(dirname "$0")"
TMPDIR=/data/data/com.termux/files/usr/tmp

echo "🛑 Matiin SEMUA proses Onyx..."
# Kill by name
pkill -9 -f "node server.js" 2>/dev/null || true
pkill -9 -f "bot/onyx-server" 2>/dev/null || true
pkill -9 -f "bot/global-chat" 2>/dev/null || true
pkill -9 -f "llama-server" 2>/dev/null || true
pkill -9 -f "ngrok" 2>/dev/null || true
sleep 2

# Kill by port (paksa)
for PORT in 3000 8081 8082 8083; do
  PIDS=$(ls /proc | grep -E '^[0-9]+$' | while read pid; do
    if [ -e "/proc/$pid/fd" ]; then
      if ls -la "/proc/$pid/fd" 2>/dev/null | grep -q "socket:\[.*\]"; then
        cat "/proc/$pid/net/tcp" 2>/dev/null | grep -q ":$PORT " && echo $pid
      fi
    fi
  done | sort -u)
  if [ -n "$PIDS" ]; then
    for PID in $PIDS; do
      CMD=$(cat /proc/$PID/cmdline 2>/dev/null | tr '\0' ' ')
      if echo "$CMD" | grep -qE "node|llama|ngrok"; then
        echo "  Killing PID $PID ($CMD)"
        kill -9 $PID 2>/dev/null || true
      fi
    done
  fi
done
sleep 2

# Lock file — cegah double run
LOCK="/data/data/com.termux/files/usr/tmp/onyx.lock"
if [ -f "$LOCK" ]; then
  OLD_PID=$(cat "$LOCK")
  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "❌ Onyx udah jalan (PID: $OLD_PID). Matiin dulu pake: kill $OLD_PID"
    exit 1
  fi
fi
echo $$ > "$LOCK"
trap "rm -f $LOCK" EXIT

# === 1. MODEL LOKAL ===
LLAMA_PID=""
if [ -f "$HOME/llama.cpp/build/bin/llama-server" ] && [ -f "$HOME/models/qwen-unfettered.gguf" ]; then
  echo "🧠 Jalanin model lokal..."
  "$HOME/llama.cpp/build/bin/llama-server" \
    -m "$HOME/models/qwen-unfettered.gguf" \
    --host 127.0.0.1 \
    --port 8080 \
    -c 2048 \
    --threads 4 \
    > "$TMPDIR/onyx-llama.log" 2>&1 &
  LLAMA_PID=$!
  sleep 8
  if curl -s -m 3 http://127.0.0.1:8080/v1/models > /dev/null 2>&1; then
    echo "✅ Model lokal jalan (PID: $LLAMA_PID)"
  else
    echo "⚠️  Model lokal gak respon."
    LLAMA_PID=""
  fi
fi

# === 2. SERVER ONYX ===
echo "🚀 Jalanin server Onyx..."
node server.js > "$TMPDIR/onyx-server.log" 2>&1 &
SERVER_PID=$!
sleep 10

if ! curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null | grep -q "200\|301\|302\|404"; then
  echo "❌ Server gagal start:"
  cat "$TMPDIR/onyx-server.log"
  exit 1
fi
echo "✅ Server jalan di http://localhost:3000"

# === 3. NGROK ===
echo "🚀 Jalanin ngrok..."
ngrok http 3000 > "$TMPDIR/onyx-ngrok.log" 2>&1 &
NGROK_PID=$!
sleep 4

NGROK_URL=$(curl -s http://127.0.0.1:4040/api/tunnels 2>/dev/null | grep -o '"public_url":"https://[^"]*"' | head -1 | cut -d'"' -f4)

echo ""
echo "════════════════════════════════════════"
echo "  ONYX CLOUD — RUNNING (PID: $$)"
echo "════════════════════════════════════════"
[ -n "$NGROK_URL" ] && echo "  🌐 $NGROK_URL"
echo "  🖥️  http://localhost:3000"
[ -n "$LLAMA_PID" ] && echo "  🧠 Model: ✅" || echo "  🧠 Model: ❌"
echo ""
echo "  Tekan Ctrl+C buat stop."
echo "════════════════════════════════════════"

trap "echo ''; echo '🛑 Stopping...'; kill $SERVER_PID $NGROK_PID $LLAMA_PID 2>/dev/null; rm -f $LOCK; exit 0" INT

# Auto-backup setiap startup
if [ -x "./backup.sh" ]; then
  echo "📦 Auto-backup..."
  ./backup.sh 2>&1 | tail -2
fi

tail -f "$TMPDIR/onyx-server.log" &
wait
